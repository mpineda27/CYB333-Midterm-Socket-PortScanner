import socket

target = '127.0.0.1'
ports = [21, 22, 80, 443]

print(f"Scanning {target}...")

for port in ports:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(1)
        result = s.connect_ex((target, port))
        if result == 0:
            print(f"Port {port} is open")
        else:
            print(f"Port {port} is closed")
